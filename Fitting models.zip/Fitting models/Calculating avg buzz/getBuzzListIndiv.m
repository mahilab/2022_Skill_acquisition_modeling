function avgBuzzList = getBuzzListIndiv(sparcFile,timesFile, lb, ub)
%This imports SAL_data and unity_data from text files for a single subject,
%and makes a vector of length 40 that contains avgbuzz for each trial.
%INPUTS.
%sparcFile: SAL_data txt file for ONE SUBJECT ONLY
%timesFile: unity_data txt file for ONE SUBJECT ONLY
%OUTPUT.
%avgBuzzList: avgBuzzes for all 40 trials for a single subject. Ready to be
%put into FODI model.

%SPARC thresholds for feedback

%Load data
% sparcFile = '2019_04_18_19_07_37_SAL_data.txt';
% timesFile = '2019_04_18_14_07_36_unity_data.txt';
sparcData = readtable(sparcFile);
timesData = readtable(timesFile);

%Find where each trial starts/ends
trialBreaks = zeros(40,2);
trialBreaks(1,1) = timesData.Var1(1);
[N, ~] = size(timesData);
index = 1;
for j = 1:N
    if timesData.Var3(j)>index
        trialBreaks(index,2) = timesData.Var1(j-1);
        index=index+1;
        trialBreaks(index,1) = timesData.Var1(j);
    end
end
trialBreaks(40,2)=timesData.Var1(N);

%Convert SPARC to Buzzes
[N, ~] = size(sparcData);
for j = 1:N
    val = sparcData.Var2(j);
    if val<lb
        sparcData.Var2(j)=1;
    elseif val>ub
        sparcData.Var2(j)=3;
    else
        sparcData.Var2(j)=2;
    end
end

%Calculate avgBuzz for each trial
avgBuzzList = zeros(1, 40);
for j =1:40
    buzzlist = sparcData.Var2(sparcData.Var1>=trialBreaks(j,1) & sparcData.Var1<=trialBreaks(j,2));
    avgBuzzList(j) = mean(buzzlist);
end
end

