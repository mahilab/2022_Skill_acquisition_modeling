
%Make avgbuzz list for each trial. Returns zeros if not in fb group 1.

%BOUNDS FOR SPARC FEEDBACK!
lb = 3.57; %Less than this means you get 1 buzz.
ub = 3.94; %More than this means you get 3 buzzes.
%Otherwise, you get 2 buzzes.

%Calculate avg buzzes for every subject
load('TrialMetrics_AllSubjsOLD.mat')
data = TrialMetrics_AllSubjs;
subjnums_grp1 = [5001,5003,5007,5011,5014,5017,5021,5023,5025,5027,5032,5035,5040,5042,5045,5047,5049,5054,5055,5056,5061,5065,5070,5074,5076,5080,5082,5086,5089,5094,5095];
for j = subjnums_grp1
    subjFolder = ['Experiment Data (Raw)\s' num2str(j)];
    
    sparcFileInfo = dir([subjFolder '\*SAL_data.txt']);
    sparcFileName = sparcFileInfo.name;
    sparcFile = [subjFolder '\' sparcFileName];
    
    timesFileInfo = dir([subjFolder '\*unity_data.txt']);
    timesFileName = timesFileInfo.name;
    timesFile = [subjFolder '\' timesFileName];
    
    avgBuzzList = getBuzzListIndiv(sparcFile, timesFile, lb, ub);
    avgBuzzList;
    
    data.AvgBuzz(data.SubjNum==j)=avgBuzzList;
end