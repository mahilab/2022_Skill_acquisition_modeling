%% PlotFittedModels.m
% Jenny Sullivan
% Modified by Charles Weeks for MT5 Data
% =============================================

% Uses fitted models stored in ModelResults_Indiv.mat to plot subject data
% and model predictions for GPL, EL, FOSI, and FODI models for the
% user-specified performance metric (AdjTime or SPARC). These plots are based
% on the plots that were in Priyanshu's original scripts
% (model_estimation_without_feedback_individual.m and
% model_estimation_with_feedback_individual.m), but I restructured the
% code so that you can generate the plots without having to re-fit all the
% models (which takes a while). 

% REQUIREMENTS:
%   - ModelResults_Indiv.mat containing the tables: PL_Results,
%   GPL_Results, EL_Results, FOSI_Results, and FODI_Results (created by
%   Fit_Individual_Models.m)

% ================================================

%% USER INPUTS %%

% Choose metric to plot: 'TrialTime' or 'SPARC'
metric = 'TrialTime';

% Plot data as-is or relative to EL:
comp2EL = 0;        % 0/1: if 1, subtracts EL fitted data from all other data series for comparison
plot_order = 1;     % 1/2: order plots by subj num (1) or difference in R2 bet FOSI and EL (2)

%%%%%%%%%%%%%%%%%%%

%% SETUP %%

% If plots ordered by difference in R2 between FOSI and EL, try to find
% DifferenceOrder table:
if plot_order == 2
    % If it exists, sort rows
    if exist('DifferenceOrder','var')
        DifferenceOrder = sortrows(DifferenceOrder,'Order','ascend');
    else
        try
            % If it doesn't exist, try to load and sort it
            load('DifferenceOrder.mat');
            DifferenceOrder = sortrows(DifferenceOrder,'Order','ascend');
        catch
            % If not found, change plot order to default
            disp('Can''t find DifferenceOrder table. Setting plot_order = 1');
            plot_order = 1;
        end
    end
end

% Set specific y ranges for plots
if comp2EL == 1
    if strcmp(metric, 'TrialTime')
        yrange = [-15 20];
    elseif strcmp(metric,'SPARC')
        yrange = [];
    end
else
    if strcmp(metric, 'TrialTime')
        yrange = [20 55];
    elseif strcmp(metric,'SPARC')
        yrange = [4 9];
    end
end

% Order of plots:
switch plot_order
    case 1      % By subj num
        subjnums_grp0 = [5078,5024]; %none
        subjltrs_grp0 = ['(b)'];
        subjnums_grp1 = [5040,5094]; %smoothness
        subjltrs_grp1 = ['(d)'];
        subjnums_grp2 = [5091,5060]; %position
        subjltrs_grp2 = ['(f)'];
        
    case 2      % By difference in R2, FOSI - EL
        subjnums_grp0 = DifferenceOrder.SubjNum(DifferenceOrder.FBGrp == 0 & DifferenceOrder.TrialMetric == metric)';
        subjnums_grp1 = DifferenceOrder.SubjNum(DifferenceOrder.FBGrp == 1 & DifferenceOrder.TrialMetric == metric)';
        subjnums_grp2 = DifferenceOrder.SubjNum(DifferenceOrder.FBGrp == 2 & DifferenceOrder.TrialMetric == metric)';
end

% Load data
load('ModelResults_Indiv.mat');

line_width = 1;

%% PLOTTING %%

for grp = 0:1;      % for each group
    % If control group:
    if grp == 0     
        subjnums = subjnums_grp0;
        subjltrs = subjltrs_grp0;
        fig_noFB = figure('DefaultLegendFontSize',7,'DefaultLegendFontSizeMode','manual');
        fig_noFB.Name = ['No FB - ' metric];
    % If smoothness feedback group:
    elseif grp == 1            
        subjnums = subjnums_grp1;
        subjltrs = subjltrs_grp1;
        fig_smthFB = figure('DefaultLegendFontSize',7,'DefaultLegendFontSizeMode','manual');
        fig_smthFB.Name = ['Smoothness FB - ' metric];
    end
    
    % For each subj:
    for i = 1:2;       
        subj_num = subjnums(i)
        
        % Get subject's actual data 
        SubjData = GPL_Results.SubjData{GPL_Results.SubjNum == subj_num & GPL_Results.TrialMetric == metric};
        
        % PL: Get predicted values and R2
        FittedData_PL = PL_Results.FittedData{PL_Results.SubjNum == subj_num & PL_Results.TrialMetric == metric};
        R2_PL = PL_Results.R2(PL_Results.SubjNum == subj_num & PL_Results.TrialMetric == metric);
        % GPL: Get predicted values and R2
        FittedData_GPL = GPL_Results.FittedData{GPL_Results.SubjNum == subj_num & GPL_Results.TrialMetric == metric};
        R2_GPL = GPL_Results.R2(GPL_Results.SubjNum == subj_num & GPL_Results.TrialMetric == metric);
        % EL: Get predicted values and R2
        FittedData_EL = EL_Results.FittedData{EL_Results.SubjNum == subj_num & EL_Results.TrialMetric == metric};
        R2_EL = EL_Results.R2(EL_Results.SubjNum == subj_num & EL_Results.TrialMetric == metric);
        % AM: Get predicted values and R2
        FittedData_AM = AM_Results.FittedData{AM_Results.SubjNum == subj_num & AM_Results.TrialMetric == metric};
        R2_AM = AM_Results.R2(AM_Results.SubjNum == subj_num & AM_Results.TrialMetric == metric);
        % FOSI: Get predicted values and R2
        FittedData_FOSI = FOSI_Results.FittedData{FOSI_Results.SubjNum == subj_num & FOSI_Results.TrialMetric == metric};
        R2_FOSI = FOSI_Results.R2(FOSI_Results.SubjNum == subj_num & FOSI_Results.TrialMetric == metric);
        
        N = length(SubjData);   % number of trials
        
        % z will be subtracted from all fitted data:
        % - If comp2EL = 0, z = 0
        % - If comp2EL = 1, z = fitted data from EL
        z = comp2EL*FittedData_EL;
        
        % Plot subj data, GPL, EL, and FOSI first
        subplot(2,2,i); hold on;
        plot(1:N,SubjData-z,'-k.','LineWidth',line_width,'MarkerSize',11);
        plot(1:N,FittedData_PL-z,'-','LineWidth',line_width,'color',[0.9290 0.6940 0.1250]);
        plot(1:N,FittedData_GPL-z,'-r','LineWidth',line_width);
        plot(1:N,FittedData_EL-z,'-m','LineWidth',line_width);
        plot(1:N,FittedData_AM-z,'-c','LineWidth',line_width);
        plot(1:N,FittedData_FOSI-z,'-b','LineWidth',line_width);
        
        legend_entries = {'Data',...
            ['3PM (.' sprintf('%0.0f',R2_PL) ')'],...
            ['4PM (.' sprintf('%0.0f',R2_GPL) ')'],...
            ['EM (.' sprintf('%0.0f',R2_EL) ')'],...
            ['APEX (.' sprintf('%0.0f',R2_AM) ')'],...
            ['FOSI (.' sprintf('%0.0f',R2_FOSI) ')']};
        
        % If subject is in smoothness/position FB group, also plot FODI
        if grp == 1
            % FODI: Get predicted values and R2
            FittedData_FODI = FODI_Results.FittedData{FODI_Results.SubjNum == subj_num & FODI_Results.TrialMetric == metric};
            R2_FODI = FODI_Results.R2(FODI_Results.SubjNum == subj_num & FODI_Results.TrialMetric == metric);
            
            plot(1:N,FittedData_FODI-z,'-g','LineWidth',line_width);
            legend_entries{end + 1} = ['FODI (.' sprintf('%0.0f',R2_FODI) ')'];
        end
        
        % Legend formatting
        [h_legend,icons] = legend(legend_entries);
        set(h_legend,'Location','best','Color','none');
        if grp == 0
            lgnd_lines = [1 5 7 9 11];
        else
            lgnd_lines = [1 6 8 10 12 14 15];
        end
        for l = lgnd_lines
            icons(l).Visible = 'off';
        end
        
        % Plot formatting
        ax = gca;
        ax.FontSize = 12;
        grid off;
        xlabel('Trial Number','FontSize',12);
        ylabel('Trial Time (seconds)','FontSize',12);
        axis tight;
        if ~isempty(yrange)
            ylim(yrange);
        end
        %ylimit = ylim;
        %ylim(ylimit+diff(ylimit).*[-0.1 0.8]);
        title([subjltrs]);
        
    end     % for each subj
    
end

for grp = 2;      
    % If control group:
    if grp == 2            
        subjnums = subjnums_grp2;
        subjltrs = subjltrs_grp2;
        fig_posFB = figure('DefaultLegendFontSize',7,'DefaultLegendFontSizeMode','manual');
        fig_posFB.Name = ['Position FB - ' metric];
    end
    
    % For each subj:
    for i = 1:2;       
        subj_num = subjnums(i)
        
        % Get subject's actual data 
        SubjData = GPL_Results.SubjData{GPL_Results.SubjNum == subj_num & GPL_Results.TrialMetric == metric};
        
        % PL: Get predicted values and R2
        FittedData_PL = PL_Results.FittedData{PL_Results.SubjNum == subj_num & PL_Results.TrialMetric == metric};
        R2_PL = PL_Results.R2(PL_Results.SubjNum == subj_num & PL_Results.TrialMetric == metric);
        % GPL: Get predicted values and R2
        FittedData_GPL = GPL_Results.FittedData{GPL_Results.SubjNum == subj_num & GPL_Results.TrialMetric == metric};
        R2_GPL = GPL_Results.R2(GPL_Results.SubjNum == subj_num & GPL_Results.TrialMetric == metric);
        % EL: Get predicted values and R2
        FittedData_EL = EL_Results.FittedData{EL_Results.SubjNum == subj_num & EL_Results.TrialMetric == metric};
        R2_EL = EL_Results.R2(EL_Results.SubjNum == subj_num & EL_Results.TrialMetric == metric);
        % AM: Get predicted values and R2
        FittedData_AM = AM_Results.FittedData{AM_Results.SubjNum == subj_num & AM_Results.TrialMetric == metric};
        R2_AM = AM_Results.R2(AM_Results.SubjNum == subj_num & AM_Results.TrialMetric == metric);
        % FOSI: Get predicted values and R2
        FittedData_FOSI = FOSI_Results.FittedData{FOSI_Results.SubjNum == subj_num & FOSI_Results.TrialMetric == metric};
        R2_FOSI = FOSI_Results.R2(FOSI_Results.SubjNum == subj_num & FOSI_Results.TrialMetric == metric);
        
        N = length(SubjData);   % number of trials
        
        % z will be subtracted from all fitted data:
        % - If comp2EL = 0, z = 0
        % - If comp2EL = 1, z = fitted data from EL
        z = comp2EL*FittedData_EL;
        
        % Plot subj data, GPL, EL, and FOSI first
        subplot(2,2,i); hold on;
        plot(1:N,SubjData-z,'-k.','LineWidth',line_width,'MarkerSize',11);
        plot(1:N,FittedData_PL-z,'-','LineWidth',line_width,'color',[0.9290 0.6940 0.1250]);
        plot(1:N,FittedData_GPL-z,'-r','LineWidth',line_width);
        plot(1:N,FittedData_EL-z,'-m','LineWidth',line_width);
        plot(1:N,FittedData_AM-z,'-c','LineWidth',line_width);
        plot(1:N,FittedData_FOSI-z,'-b','LineWidth',line_width);
        
        legend_entries = {'Data',...
            ['3PM (.' sprintf('%0.0f',R2_PL) ')'],...
            ['4PM (.' sprintf('%0.0f',R2_GPL) ')'],...
            ['EM (.' sprintf('%0.0f',R2_EL) ')'],...
            ['APEX (.' sprintf('%0.0f',R2_AM) ')'],...
            ['FOSI (.' sprintf('%0.0f',R2_FOSI) ')']};
        
        % If subject is in smoothness/position FB group, also plot FODI
        if grp == 2
            % FODI: Get predicted values and R2
            FittedData_FODI = FODI_Results.FittedData{FODI_Results.SubjNum == subj_num & FODI_Results.TrialMetric == metric};
            R2_FODI = FODI_Results.R2(FODI_Results.SubjNum == subj_num & FODI_Results.TrialMetric == metric);
            
            plot(1:N,FittedData_FODI-z,'-g','LineWidth',line_width);
            legend_entries{end + 1} = ['FODI (.' sprintf('%0.0f',R2_FODI) ')'];
        end
        
        % Legend formatting
        [h_legend,icons] = legend(legend_entries);
        set(h_legend,'Location','best','Color','none');
        if grp == 0
            lgnd_lines = [1 5 7 9 11];
        else
            lgnd_lines = [1 6 8 10 12 14 15];
        end
        for l = lgnd_lines
            icons(l).Visible = 'off';
        end
        
        % Plot formatting
        ax = gca;
        ax.FontSize = 12;
        grid off;
        xlabel('Trial Number','FontSize',12);
        ylabel('Trial Time (seconds)','FontSize',12);
        axis tight;
        if ~isempty(yrange)
            ylim(yrange);
        end
        %ylimit = ylim;
        %ylim(ylimit+diff(ylimit).*[-0.1 0.8]);
        title([subjltrs]);
        
    end     % for each subj
    
end