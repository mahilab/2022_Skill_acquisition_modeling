%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Purpose: Fit a single input first-order linear dynamic model to provided input and output data 
% Inputs: A subject's performance data for all trials, corresponding practice time data,
% initial estimate from the exponential model, function value from the exponential fitting, 
% initial performance estimate from the exponential model and number of 
% times the fitting should be performed with random initialization
% Outputs: Simulated performance data, Afs (retention rate), 
% Bfs (learning rate), (1-A)*c (offset), 
% initial state estimate, fit (percent normalized root mean square error), 
% minimized function value, r2
% NOTE: Refer to the modeling paper for details of the nomenclature
% Authors: Priyanshu Agarwal
% Contact: mail2priyanshu@gmail.com

% EXAMPLE INPUTS:
% fit_first_order_model(SPARC,Time_metric,[A_EL,K_EL,B_EL],resnorm,y_sim_EL(1),ntrials);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [y_sim, retention_rate, learning_rate,offset,xi, fit, fval, r2]...
     = fit_first_order_model(y,u,p0,fval,yi_EL,ntrials)
    
fval;
 Ts = 1;
data = iddata(y,u,Ts);
A = [];
b = [];
Aeq = [];
beq = [];
lb = [0 -inf 0 0]; % lower bound constraint on unknown parameters
ub = [1 inf inf inf]; % upper bound constraint on unknown parameters
options = optimoptions('fmincon','Display','off','Algorithm','sqp');
minval = inf;

% estimate multiple times with random initialization to achieve global
% minimum (best fitting)
for i=1:ntrials
    x0 = [rand rand yi_EL i*rand];
    [x1,fval1] = fmincon(@(x) evaluate_cost_fo_u1(x,data),x0,A,b,Aeq,beq,lb,ub,[],options);
    % keep the best solution so far
    if(fval1<minval)
        xmin = x1;
        minval = fval1;
    end
end

y_sim = zeros(length(y),1);
if(minval<fval)
    % if dynamic model fitting is better use the optimized solution
    A=xmin(1);
    B=xmin(2);
    xi = xmin(3);
    x_of = xmin(4);
    fval = minval;
else
    % if exponential fitting is better reduce the dynamic model to
    % exponential and initialize the dynamic model parameters using the
    % exponential model parameter estimates
    A=exp(p0(2));
    B=0;
    x_of = -p0(3)*(exp(p0(2))-1);
    xi = yi_EL;
end

retention_rate = A;
learning_rate = B;
offset = x_of;
y_sim(1) = xi;
for i=2:length(y)
    y_sim(i) = A*y_sim(i-1) + B*u(i-1) + x_of;
end
fit = 100*(1-norm(y-y_sim)/norm(y-mean(y)));
r2 = 100*(1-norm(y-y_sim)^2/norm(y-mean(y))^2);
end

% cost function for model fitting
function cost = evaluate_cost_fo_u1(x,data)
A=x(1);
B=x(2);
y_sim = zeros(length(data.y),1);
y_sim(1) = x(3);
for i=2:length(data.y)
    y_sim(i) = A*y_sim(i-1) + B*data.u(i-1) + x(4);
end
cost = (norm(y_sim-data.y))^2;
end