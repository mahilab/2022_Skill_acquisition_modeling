%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Purpose: Fit a dual input first-order linear dynamic model to provided input and output data 
% Inputs: A subject's performance data for all trials, corresponding model input data,
% initial estimate from the exponential model, function value from the exponential fitting, 
% initial performance estimate from the exponential model and number of 
% times the fitting should be performed with random initialization
% Outputs: Simulated performance data, Afs (retention rate), 
% Bfs (learning rates), (1-A)*cfs (offset), 
% initial state estimate, fit (percent normalized root mean square error), 
% minimized function value, r2
% NOTE: Refer to the modeling paper for details of the nomenclature
% Authors: Priyanshu Agarwal
% Contact: mail2priyanshu@gmail.com
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [y_sim, retention_rate, learning_rates, offset,xi, fit, r2] = fit_first_order_model_two_input(y,u,xsol,fval,ntrials)
Ts = 1;
% u = [0 0; u];
% u(end,:) = [];
data = iddata(y,u,Ts);

A = [];
b = [];
Aeq = [];
beq = [];
lb = [0 -inf -inf 0 0];
ub = [1 inf inf inf inf];
nonlcon = [];
options = optimoptions('fmincon','Display','off','Algorithm','sqp');
minval = inf;

% estimate multiple times with random initialization to achieve global
% minimum (best fitting)
for i=1:ntrials
    if i==1
        x0 = [0 0 0 0 0];
    else
        x0 = [rand rand rand y(1) i*rand];
    end    
    [x,fval1] = fmincon(@(x) evaluate_cost_fo_u2(x,data),x0,A,b,Aeq,beq,lb,ub,nonlcon,options);
    % keep the best solution so far
    if(fval1<minval)
        xmin = x;
        minval = fval1;
    end
end

if(minval<fval)
    % if dynamic model fitting is better use the optimized solution
    A=xmin(1);
    B=[xmin(2), xmin(3)];
    xi = xmin(4);
    offset = xmin(5);
else
    % if exponential fitting is better reduce the dynamic model to
    % exponential and initialize the dynamic model parameters using the
    % exponential model parameter estimates
    A = xsol(1);
    B = [xsol(2), 0];
    offset = xsol(3);
    xi = xsol(4);
end

retention_rate = A;
learning_rates(1) = B(1);
learning_rates(2) = B(2);
y_sim = zeros(length(y),1);
y_sim(1) = xi;
for i=2:length(y)
    y_sim(i) = A*y_sim(i-1) + B(1)*u(i-1,1)+B(2)*u(i-1,2) + offset;
end
% y_sim
fit = 100*(1-norm(y-y_sim)/norm(y-mean(y)));
r2 = 100*(1-norm(y-y_sim)^2/norm(y-mean(y))^2);
end

% cost function for model fitting
function cost = evaluate_cost_fo_u2(x,data)
A=x(1);
B=[x(2), x(3)];
y_sim = zeros(length(data.y),1);
y_sim(1) = x(4);
for i=2:length(data.y)
    y_sim(i) = A*y_sim(i-1) + B*data.u(i-1,:)' + x(5);
end
cost = (norm(y_sim-data.y))^2;
end