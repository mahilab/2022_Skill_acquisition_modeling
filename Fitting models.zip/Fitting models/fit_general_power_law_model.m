%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Purpose: Fit general power law (GPL) model to provided input and output data
% Execution syntax: fit_general_power_law_model(SPARC, Trial_number, [A_PL, K_PL, B_PL], nattempts);
% Inputs: A subject's performance data for all trials, corresponding practice time data,
% initial estimate from power law and number of times the fitting should be 
% performed with random initialization
% Outputs: Simulated performance data, ap, kp, bp, ep, fit (percent normalized root
% mean square error), r2
% Comment: Note that kp is negative here and the minus sign is not
% considered explicitly in the function
% NOTE: Refer to the modeling paper for details of the nomenclature
% Authors: Priyanshu Agarwal
% Contact: mail2priyanshu@gmail.com
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [y_sim, ap, kp, bp, experience, fit, r2] = fit_general_power_law_model(y,u,xi,ntrials)
% general power law function
fun = @(x)norm(x(1)*(u+x(4)).^x(2)+x(3)-y)^2;

%This stuff is mostly garbage unless you have a REALLY good reason to mess
%with upper bounds due to unlucky experimental data.
%----
A = [];
b = [];
Aeq = [];
beq = [];
lb = [0 -1 0 0]; % lower bound constraint on unknown parameters
ub = [inf 0 inf inf]; % upper bound constraint on unknown parameters
options = optimoptions('fmincon','Display','off','Algorithm','sqp');
%----

minval = inf;
for i =1:ntrials
   x0 = [rand, -rand, rand, rand]; %<-- I don't understand why this is used as a basepoint.
   [x1,fval] = fmincon(fun,x0,A,b,Aeq,beq,lb,ub,[],options);
   if(fval<minval)
      xmin = x1;
      minval = fval;
   end
end
ap = xmin(1);
kp = xmin(2);
bp = xmin(3);
experience = xmin(4);
y_sim =ap*(u+experience).^kp+bp;
fit = 100*(1-norm(y-y_sim)/norm(y-mean(y)));
r2 = 100*(1-norm(y-y_sim)^2/norm(y-mean(y))^2);
end