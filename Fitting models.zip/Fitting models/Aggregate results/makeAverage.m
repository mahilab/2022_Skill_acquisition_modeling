function avglist = makeAverage
    load('TrialMetrics_AllSubjs.mat')
    times = reshape(TrialMetrics_AllSubjs.TrialTime,[40,85]);

    avglist = zeros(1,40);
    for j = 1:40
       avglist(j) = mean(times(j,:)); 
    end
end