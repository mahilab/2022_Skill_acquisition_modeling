%% Fit_Individual_Models.m
% Jenny Sullivan 
% Modified by Charlie Weeks for MT5 Data
% ===============================================

% This script is a modified and consolidated version of Priyanshu's
% model_estimation_without_feedback_individual.m and
% model_estimation_with_feedback_individual.m. 

% Uses trial data stored in TrialMetrics_AllSubjs table to fit power law,
% generalized power law, exponential law, FOSI, and FODI models to
% individual subject data (both Adj Time metric and SPARC). Computes 3
% goodness-of-fit metrics for each: NRMSE, R2, and MAD. Stores fitted
% parameters and goodness-of-fit measures for each subject and each
% performance metric in tables PL_Results, GPL_Results, EL_Results,
% FOSI_Results, FODI_Results and saves them to ModelResults_Indiv.mat.

% REQUIREMENTS:
%   - TrialMetrics_AllSubjs table 
%   - fit_power_law_model.m 
%   - fit_general_power_law_model.m 
%   - fit_exponential_law_model.m 
%   - fit_APEX_model.m
%   - fit_first_order_model.m 
%   - fit_first_order_model_two_input.m 

% ===========================================================

%% USER INPUTS %%
clear;

% Choose specific metric(s) to run (1/0 = yes/no):
do_SPARC = 0;             % Fit SPARC data? 
do_TrialTime = 1;       % Fit Total Time data? 
do_runtime_plots = 0;   % Plot results? (can also use PlotFittedModels.m)

%%%%%%%%%%%%%%%%%%

%% Initialization
PL_Results = table();   % [SubjNum, FB grp, TrialMetric, SubjData, A_PL, K_PL, B_PL, NRMSE, R2, MAD]
GPL_Results = table();  % [SubjNum, FB grp, TrialMetric, SubjData, FittedData, A_GPL, K_GPL, B_GPL, E_GPL, NRMSE, R2, MAD]
EL_Results = table();   % [SubjNum, FB grp, TrialMetric, SubjData, FittedData, A_EL, K_EL, B_EL, NRMSE, R2, MAD]
AM_Results = table(); % [SubjNum, FB grp, TrialMetric, SubjData, FittedData, A_AM, K_AA, K_AZ, B_A, NRMSE, R2, MAD]
FOSI_Results = table(); % [SubjNum, FB grp, TrialMetric, SubjData, FittedData, RetRate, LearnRate, Offset, InitVal, NRMSE, R2, MAD]
FODI_Results = table(); % [SubjNum, FB grp, TrialMetric, SubjData, FittedData, RetRate, LearnRate, Offset, InitVal, NRMSE, R2, MAD]

%%% Load trial data for subjects in Feedback 0 (no FB) and Feedback 1 (SPARC FB):
load('TrialMetrics_AllSubjs.mat')
TrialMetrics_AllSubjs.TrialTime(1:40)=makeAverage;
TrialData_BothGrps = TrialMetrics_AllSubjs(TrialMetrics_AllSubjs.Feedback ~= 3, :);
SubjNums_BothGrps = unique(TrialData_BothGrps.SubjNum)'
N_sub = length(SubjNums_BothGrps);      % number of subjects

nattempts = 10; % number of times to run estimation algorithm with random initialization
rng('shuffle'); % randomize random number generator

%%% directory for figure output
figure_dir = 'figures/single_rate_learning/no_tactor_feedback/';
%%% Figure specs
font_size = 10;
line_width = 2;
print_flag = 0; % 1 to print figures, 0 otherwise
if(print_flag)
    close all;
    set(0, 'DefaultFigureWindowStyle', 'normal');
    diary('No_Feedback_individual.txt');
    diary on;
else
    set(0, 'DefaultFigureWindowStyle', 'normal');
end


%% For each subject, fit each model to each metric 

p = 1;      % counter for subplots

for subject_num = SubjNums_BothGrps
    
    disp(' ');
    disp(['subj num = ' num2str(subject_num)]);
    
    %%% Retrieve results for a subject & remove "invalid" trials
    SubjTrialData = TrialData_BothGrps(TrialData_BothGrps.SubjNum == subject_num,:);
    SubjTrialData(SubjTrialData.Valid == 0,:) = [];
    
    %%% Get FB group for this subj (0 = no FB, 1 = SPARC)
    FB_grp = mode(SubjTrialData.Feedback);
    
    %%% Subject's SPARC data
    SPARC = SubjTrialData.SPARC;
    
    %%% Subject's Total Time data
    TrialTime = SubjTrialData.TrialTime;
    
    %%% Feedback metric: avg # of buzzes per trial
    AvgBuzz = SubjTrialData.AvgBuzz;
    
    %%% Feedback metric for position feedback group:
    TimeBuzz = SubjTrialData.TimeOut
    
    N = height(SubjTrialData);
    Trial_number = (1:N)';      % Note: This renumbers trials if any were removed!
    
    
    %%
    % =========================================================================================
    % Fit SPARC data
    % =========================================================================================
    
    if do_SPARC
        
        disp(' ')
        disp('---- SPARC ----')
        
        %%% Power law model (regular) %%%
        disp(['FITTING POWER LAW MODEL (SPARC, subj ' num2str(subject_num) ')..................'])
        [~, A_PL, K_PL, B_PL, Fit_model_PL, R2_model_PL] = ...
            fit_power_law_model(SPARC, Trial_number, nattempts);
        
        NewRow_PL = table(subject_num, FB_grp, {'SPARC'}, {SPARC}, A_PL, K_PL, B_PL, Fit_model_PL, R2_model_PL);
        PL_Results = [PL_Results; NewRow_PL];
        
        
        %%% General power law model %%%
        disp(['FITTING GENERAL POWER LAW MODEL (SPARC, subj ' num2str(subject_num) ')..................'])
        [y_sim_GPL, A_GPL, K_GPL, B_GPL, E_GPL, Fit_model_GPL, R2_model_GPL] = ...
            fit_general_power_law_model(SPARC, Trial_number, [A_PL, K_PL, B_PL], nattempts);
        
        NewRow_GPL = table(subject_num, FB_grp, {'SPARC'}, {SPARC}, {y_sim_GPL}, A_GPL, K_GPL, B_GPL, E_GPL, Fit_model_GPL, R2_model_GPL);
        GPL_Results = [GPL_Results; NewRow_GPL];
        
        
        %%% Exponential law model %%%
        disp(['FITTING EXPONENTIAL LAW MODEL (SPARC, subj ' num2str(subject_num) ')..................'])
        [y_sim_EL, A_EL, K_EL, B_EL, Fit_model_EL, resnorm, R2_model_EL] =...
            fit_exponential_law_model(SPARC, Trial_number, nattempts);
        
        NewRow_EL = table(subject_num, FB_grp, {'SPARC'}, {SPARC}, {y_sim_EL}, A_EL, K_EL, B_EL, Fit_model_EL, R2_model_EL);
        EL_Results = [EL_Results; NewRow_EL];
        
        %%% APEX model %%%
        disp(['FITTING APEX MODEL (SPARC, subj ' num2str(subject_num) ')..................'])
        [y_sim_AM, A_A, K_A, B_A, K_Z, Fit_APEX_model, R2_APEX_model] =...
            fit_APEX_model(SPARC, Trial_number, nattempts);
        
        NewRow_AM = table(subject_num, FB_grp, {'SPARC'}, {SPARC}, {y_sim_AM}, A_A, K_A, B_A, K_Z, Fit_APEX_model, R2_APEX_model);
        AM_Results = [AM_Results; NewRow_AM];
        
        %%% FOSI model %%%
        disp(['FITTING FOSI MODEL (SPARC, subj ' num2str(subject_num) ')..................'])
        [y_sim_FOSI, Retention_FOSI, Learning_FOSI, Offset_FOSI, Init_state_FOSI, Fit_model_FOSI,fval, R2_model_FOSI] = ...
            fit_first_order_model(SPARC, TrialTime, [A_EL, K_EL, B_EL], resnorm, y_sim_EL(1), nattempts);
        
        NewRow_FOSI = table(subject_num, FB_grp, {'SPARC'}, {SPARC}, {y_sim_FOSI}, Retention_FOSI, Learning_FOSI, Offset_FOSI, Init_state_FOSI, Fit_model_FOSI, R2_model_FOSI);
        FOSI_Results = [FOSI_Results; NewRow_FOSI];
        
        %%% FODI model %%% 
        %%% (For subjs in group 1 only)
        if FB_grp == 1
            disp(['FITTING FODI MODEL (SPARC, subj ' num2str(subject_num) ')..................'])
            [y_sim_FODI,Retention_FODI, Learning_FODI, Offset_FODI, Init_state_FODI, Fit_model_FODI, R2_model_FODI] =...
                fit_first_order_model_two_input(SPARC,[TrialTime,AvgBuzz],[Retention_FOSI, Learning_FOSI,Offset_FOSI, Init_state_FOSI],fval,nattempts);
            
            % Note: 2 learning rate coeffs for FODI
            NewRow_FODI = table(subject_num, FB_grp, {'SPARC'}, {SPARC}, {y_sim_FODI}, Retention_FODI, {Learning_FODI}, Offset_FODI, Init_state_FODI, Fit_model_FODI, R2_model_FODI);
            FODI_Results = [FODI_Results; NewRow_FODI];
        elseif FB_grp == 2
             disp(['FITTING FODI MODEL (SPARC, subj ' num2str(subject_num) ')..................'])
            [y_sim_FODI,Retention_FODI, Learning_FODI, Offset_FODI, Init_state_FODI, Fit_model_FODI, R2_model_FODI] =...
                fit_first_order_model_two_input(SPARC,[TrialTime,TimeBuzz],[Retention_FOSI, Learning_FOSI,Offset_FOSI, Init_state_FOSI],fval,nattempts);
            
            % Note: 2 learning rate coeffs for FODI
            NewRow_FODI = table(subject_num, FB_grp, {'SPARC'}, {SPARC}, {y_sim_FODI}, Retention_FODI, {Learning_FODI}, Offset_FODI, Init_state_FODI, Fit_model_FODI, R2_model_FODI);
            FODI_Results = [FODI_Results; NewRow_FODI];
        else
            y_sim_FODI = [];
            Fit_model_FODI = [];
        
        end
        
        
        %%% SPARC PLOTTING %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        if do_runtime_plots
            figure(2);
            subplot(4,8,p);
            plot(1:N,SPARC,'-b',1:N,y_sim_GPL,'--r',...
                1:N,y_sim_EL,':m',...
                1:N,y_sim_FOSI,'-.k','LineWidth',line_width);
            
            legend_entries = {'Data',...
                ['PL (' sprintf('%0.2f',Fit_model_GPL) '%)'],...
                ['EL (' sprintf('%0.2f',Fit_model_EL) '%)'],...
                ['FOSI (' sprintf('%0.2f',Fit_model_FOSI) '%)']};
            
            if FB_grp == 1
                hold on;
                plot(1:N,y_sim_FODI,'-+g','LineWidth',line_width);
                legend_entries{end + 1} = ['FODI (' sprintf('%0.2f',Fit_model_FODI) '%)'];
            elseif FB_grp == 2
                hold on;
                plot(1:N,y_sim_FODI,'-+g','LineWidth',line_width);
                legend_entries{end + 1} = ['FODI (' sprintf('%0.2f',Fit_model_FODI) '%)'];
            end
            
            h_legend = legend(legend_entries);

            set(h_legend,'FontSize',font_size);
            grid on;
            xlabel('Trial Number \rightarrow','fontsize',font_size+2)
            ylabel('Spectral Arc Length \rightarrow','fontsize',font_size+2)
            axis tight;
            ylimit = ylim;
            ylim(ylimit+diff(ylimit).*[-0.1 1.1]);
            title(['subj num ' num2str(subject_num)])
            
            hold off;
        end
        
        %%% Log-log scale
        if 0
            figure(5);
            loglog((1:N),(SPARC),'-b',...
                (1:N),(y_sim_GPL),'--r',...
                (1:N),(y_sim_EL),':m',...
                (1:N),(y_sim_FOSI),'-.k','LineWidth',line_width);
            
            legend_entries = {'Data','PL','EL','FOSI'};
            
            if FB_grp == 1
                hold on;
                loglog((1:N),(y_sim_FODI),'-+g','LineWidth',line_width);
                legend_entries{end + 1} = 'FODI';
            elseif FB_grp == 2
                hold on;
                loglog((1:N),(y_sim_FODI),'-+g','LineWidth',line_width);
                legend_entries{end + 1} = 'FODI';
            end
            
            h_legend = legend(legend_entries);
            set(h_legend,'FontSize',font_size,'Orientation','horizontal');
            grid on;
            xlabel('Trial Number \rightarrow','fontsize',font_size+2)
            ylabel('Spectral Arc Length \rightarrow','fontsize',font_size+2)
            axis tight;
            ylimit = ylim;
            ylim(ylimit+diff(ylimit).*[-0.1 0.4]);
            title(['subj num ' num2str(subject_num)])
            hold off;
        end
        
    end     % end if do_SPARC
    
    %%
    % =========================================================================================
    % Fit Total Time data
    % =========================================================================================
    
    if do_TrialTime
        
        disp(' ')
        disp('---- TrialTime ----')
        
        %%% Power law model (regular) %%%
        disp(['FITTING POWER LAW MODEL (TrialTime, subj ' num2str(subject_num) ')..................'])
        [~, A_PL, K_PL, B_PL, Fit_model_PL, R2_model_PL] = ...
            fit_power_law_model(TrialTime, Trial_number, nattempts);
        
        NewRow_PL = table(subject_num, FB_grp, {'TrialTime'}, {TrialTime}, A_PL, K_PL, B_PL, Fit_model_PL, R2_model_PL);
        PL_Results = [PL_Results; NewRow_PL];
        

        %%% General power law model %%%
        disp(['FITTING GENERAL POWER LAW MODEL (TrialTime, subj ' num2str(subject_num) ')..................'])
        [y_sim_GPL, A_GPL, K_GPL, B_GPL, E_GPL, Fit_model_GPL, R2_model_GPL] = ...
            fit_general_power_law_model(TrialTime, Trial_number, [A_PL, K_PL, B_PL], nattempts);
        
        NewRow_GPL = table(subject_num, FB_grp, {'TrialTime'}, {TrialTime}, {y_sim_GPL}, A_GPL, K_GPL, B_GPL, E_GPL, Fit_model_GPL, R2_model_GPL);
        GPL_Results = [GPL_Results; NewRow_GPL];
        
        
        %%% Exponential law model %%%
        disp(['FITTING EXPONENTIAL LAW MODEL (TrialTime, subj ' num2str(subject_num) ')..................'])
        [y_sim_EL, A_EL, K_EL, B_EL, Fit_model_EL, resnorm, R2_model_EL] =...
            fit_exponential_law_model(TrialTime, Trial_number, nattempts);
        
        NewRow_EL = table(subject_num, FB_grp, {'TrialTime'}, {TrialTime}, {y_sim_EL}, A_EL, K_EL, B_EL, Fit_model_EL, R2_model_EL);
        EL_Results = [EL_Results; NewRow_EL];
        
        %%% APEX model %%%
        disp(['FITTING APEX MODEL (TrialTime, subj ' num2str(subject_num) ')..................'])
        [y_sim_AM, A_A, K_A, B_A, K_Z, Fit_APEX_model, R2_APEX_model] =...
            fit_APEX_model(TrialTime, Trial_number, nattempts);
        
        NewRow_AM = table(subject_num, FB_grp, {'TrialTime'}, {TrialTime}, {y_sim_AM}, A_A, K_A, B_A, K_Z, Fit_APEX_model, R2_APEX_model);
        AM_Results = [AM_Results; NewRow_AM];
        
        %%% FOSI model %%%
        disp(['FITTING FOSI MODEL (TrialTime, subj ' num2str(subject_num) ')..................'])
        [y_sim_FOSI, Retention_FOSI, Learning_FOSI, Offset_FOSI, Init_state_FOSI, Fit_model_FOSI,fval, R2_model_FOSI] = ...
            fit_first_order_model(TrialTime, TrialTime, [A_EL, K_EL, B_EL], resnorm, y_sim_EL(1), nattempts);
        
        NewRow_FOSI = table(subject_num, FB_grp, {'TrialTime'}, {TrialTime}, {y_sim_FOSI}, Retention_FOSI, Learning_FOSI, Offset_FOSI, Init_state_FOSI, Fit_model_FOSI, R2_model_FOSI);
        FOSI_Results = [FOSI_Results; NewRow_FOSI];
        
        
        %%% FODI model %%% 
        %%% (For subjs in group 1 only)
        if FB_grp == 1
            disp(['FITTING FODI MODEL (TrialTime, subj ' num2str(subject_num) ')..................'])
            [y_sim_FODI,Retention_FODI, Learning_FODI, Offset_FODI, Init_state_FODI, Fit_model_FODI, R2_model_FODI] =...
                fit_first_order_model_two_input(TrialTime,[TrialTime,AvgBuzz],[Retention_FOSI, Learning_FOSI,Offset_FOSI, Init_state_FOSI],fval,nattempts);
            
            % Note: 2 learning rate coeffs for FODI
            NewRow_FODI = table(subject_num, FB_grp, {'TrialTime'}, {TrialTime}, {y_sim_FODI}, Retention_FODI, {Learning_FODI}, Offset_FODI, Init_state_FODI, Fit_model_FODI, R2_model_FODI);
            FODI_Results = [FODI_Results; NewRow_FODI];
        elseif FB_grp == 2
            disp(['FITTING FODI MODEL (TrialTime, subj ' num2str(subject_num) ')..................'])
            [y_sim_FODI,Retention_FODI, Learning_FODI, Offset_FODI, Init_state_FODI, Fit_model_FODI, R2_model_FODI] =...
                fit_first_order_model_two_input(TrialTime,[TrialTime,TimeBuzz],[Retention_FOSI, Learning_FOSI,Offset_FOSI, Init_state_FOSI],fval,nattempts);
            
            % Note: 2 learning rate coeffs for FODI
            NewRow_FODI = table(subject_num, FB_grp, {'TrialTime'}, {TrialTime}, {y_sim_FODI}, Retention_FODI, {Learning_FODI}, Offset_FODI, Init_state_FODI, Fit_model_FODI, R2_model_FODI);
            FODI_Results = [FODI_Results; NewRow_FODI];
        else
            y_sim_FODI = [];
            Fit_model_FODI = [];
        
        end


        %%% ADJ TIME PLOTTING %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        if do_runtime_plots
            figure(3);
            subplot(4,8,p);
            plot(1:N,TrialTime,'-b',1:N,y_sim_GPL,'--r',...
                1:N,y_sim_EL,':m',...
                1:N,y_sim_FOSI,'-.k','LineWidth',line_width);
            
            legend_entries = {'Data',...
                ['PL (' sprintf('%0.2f',Fit_model_PL) '%)'],...
                ['EL (' sprintf('%0.2f',Fit_model_EL) '%)'],...
                ['FOSI (' sprintf('%0.2f',Fit_model_FOSI) '%)']};
            
            if FB_grp == 1
                hold on;
                plot(1:N,y_sim_FODI,'-+g','LineWidth',line_width);
                legend_entries{end + 1} = ['FODI (' sprintf('%0.2f',Fit_model_FODI) '%)'];
            elseif FB_grp == 2
                hold on;
                plot(1:N,y_sim_FODI,'-+g','LineWidth',line_width);
                legend_entries{end + 1} = ['FODI (' sprintf('%0.2f',Fit_model_FODI) '%)'];
            end
            
            h_legend = legend(legend_entries);
            
            set(h_legend,'FontSize',font_size);
            grid on;
            xlabel('Trial Number \rightarrow','fontsize',font_size+2)
            ylabel('Time Metric \rightarrow','fontsize',font_size+2)
            axis tight;
            ylimit = ylim;
            ylim(ylimit+diff(ylimit).*[-0.1 0.8]);
            title(['subj num ' num2str(subject_num)])
            
            hold off;
        end
        
        %%% Log-log scale
        if 0
            figure(6);
            loglog((1:N),(TrialTime),'-b',...
                (1:N),(y_sim_GPL),'--r',...
                (1:N),(y_sim_EL),':m',...
                (1:N),(y_sim_FOSI),'-.k','LineWidth',line_width);
            
            legend_entries = {'Data','PL','EL','FOSI'};
            
            if FB_grp == 1
                hold on;
                loglog((1:N),(y_sim_FODI),'-+g','LineWidth',line_width);
                legend_entries{end + 1} = 'FODI';
            elseif FB_grp == 2
                hold on;
                loglog((1:N),(y_sim_FODI),'-+g','LineWidth',line_width);
                legend_entries{end + 1} = 'FODI';
            end
            
            h_legend = legend(legend_entries);
            %h_legend = legend('Data','PL','EL','FOSI','FODI');
            set(h_legend,'FontSize',font_size,'Orientation','horizontal');
            grid on;
            xlabel('Trial Number \rightarrow','fontsize',font_size+2)
            ylabel('Time Metric \rightarrow','fontsize',font_size+2)
            axis tight;
            ylimit = ylim;
            ylim(ylimit+diff(ylimit).*[-0.1 1.7]);
            title(['subj num ' num2str(subject_num)])
            hold off;
        end
        
    end     % if do_TrialTime
    
    
        %% PLOTTING - SPECIAL FORMAT

        plot_name_str = {'number_of_submovement_response_',...
            'spectral_arc_length_response_','time_metric_response_',...
            'number_of_submovement_log_','spectral_arc_length_log_',...
            'time_metric_log_'};
        
        if(print_flag)
            if(~exist(figure_dir,'dir'))
                mkdir(figure_dir);
            end
            for i = 1:length(plot_name_str)
                plot_name = [figure_dir plot_name_str{i} num2str(subject_num)];
                figure(i);
                set(gcf,'Units','Inches');
                pos = get(gcf,'Position');
                set(gcf,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
                print(gcf,plot_name,'-dpdf','-r0')
            end
        end
        
        %%

   % pause  % after each subjet
    p = p+1;    % increment subplot counter
    
end     % for each subject

%% Set column names for output tables %%

PL_Results.Properties.VariableNames = {'SubjNum', 'FBGrp', 'TrialMetric', 'SubjData', 'A_PL', 'K_PL', 'B_PL', 'NRMSE', 'R2'};
PL_Results.TrialMetric = categorical(PL_Results.TrialMetric);

GPL_Results.Properties.VariableNames = {'SubjNum', 'FBGrp', 'TrialMetric', 'SubjData', 'FittedData', 'A_GPL', 'K_GPL', 'B_GPL', 'E_GPL', 'NRMSE', 'R2'};
GPL_Results.TrialMetric = categorical(GPL_Results.TrialMetric);

EL_Results.Properties.VariableNames = {'SubjNum', 'FBGrp', 'TrialMetric', 'SubjData', 'FittedData', 'A_EL', 'K_EL', 'B_EL', 'NRMSE', 'R2'};
EL_Results.TrialMetric = categorical(EL_Results.TrialMetric);

AM_Results.Properties.VariableNames = {'SubjNum', 'FBGrp', 'TrialMetric', 'SubjData', 'FittedData', 'A_A', 'K_A','B_A', 'K_Z', 'NRMSE', 'R2'};
AM_Results.TrialMetric = categorical(AM_Results.TrialMetric);

FOSI_Results.Properties.VariableNames = {'SubjNum', 'FBGrp', 'TrialMetric', 'SubjData', 'FittedData', 'RetRate', 'LearnRate', 'Offset', 'InitVal', 'NRMSE', 'R2'};
FOSI_Results.TrialMetric = categorical(FOSI_Results.TrialMetric);

FODI_Results.Properties.VariableNames = {'SubjNum', 'FBGrp', 'TrialMetric', 'SubjData', 'FittedData', 'RetRate', 'LearnRate', 'Offset', 'InitVal', 'NRMSE', 'R2'};
FODI_Results.TrialMetric = categorical(FODI_Results.TrialMetric);


%% Compute MAD %%
%EVERTHING IS HALVED BECAUSE ONLY RUNNING TRIAL TIME
 %%% 188 rows: 85 subjs x 2 metrics
 GPL_Results.MAD = zeros(85,1);
 EL_Results.MAD = zeros(85,1);
 AM_Results.MAD = zeros(85,1);
 FOSI_Results.MAD = zeros(85,1);
 
 %%% 126 rows: 56 subjs (grp 1 & 2 only) x 2 metrics
 FODI_Results.MAD = zeros(56,1);
 
 for i = 1:85 
     i
     GPL_Results.MAD(i) = mean(abs(GPL_Results.SubjData{i,1} - GPL_Results.FittedData{i,1}));
     EL_Results.MAD(i) = mean(abs(EL_Results.SubjData{i,1} - EL_Results.FittedData{i,1}));
     AM_Results.MAD(i) = mean(abs(AM_Results.SubjData{i,1} - AM_Results.FittedData{i,1}));
     FOSI_Results.MAD(i) = mean(abs(FOSI_Results.SubjData{i,1} - FOSI_Results.FittedData{i,1}));
     if i < 57   % only 56 rows for FODI
         FODI_Results.MAD(i) = mean(abs(FODI_Results.SubjData{i,1} - FODI_Results.FittedData{i,1}));
     end
 end


%% Save results tables to mat file %%
disp('Saving........')
save('AVG_ModelResults_Indiv.mat','PL_Results','GPL_Results','EL_Results', 'AM_Results', 'FOSI_Results','FODI_Results');
disp('Done!!')

% +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



