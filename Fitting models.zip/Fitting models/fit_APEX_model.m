
function [y_sim, aa, ka, ba, kz, fit, r2] = fit_APEX_model(y,u,ntrials)
% APEX function
fun = @(x)norm(x(1)*exp(x(2)*u).*u.^x(4)+x(3)-y)^2;

%This stuff is mostly garbage unless you have a REALLY good reason to mess
%with upper bounds due to unlucky experimental data.
%----
A = [];
b = [];
Aeq = [];
beq = [];
lb = [0 -1 0 -1]; % lower bound constraint on unknown parameters
ub = [inf 0 inf 0]; % upper bound constraint on unknown parameters
options = optimoptions('fmincon','Display','off','Algorithm','sqp');
%----

minval = inf;
for i =1:ntrials
   x0 = [i*rand, -rand, i*rand, -rand]; %<-- I don't understand why this is used as a basepoint.
   [x1,fval] = fmincon(fun,x0,A,b,Aeq,beq,lb,ub,[],options);
   if(fval<minval)
      xmin = x1;
      minval = fval;
   end
end
aa = xmin(1);
ka = xmin(2);
ba = xmin(3);
kz = xmin(4);
y_sim =aa*exp(ka*u).*u.^kz+ba;
fit = 100*(1-norm(y-y_sim)/norm(y-mean(y)));
r2 = 100*(1-norm(y-y_sim)^2/norm(y-mean(y))^2);
end